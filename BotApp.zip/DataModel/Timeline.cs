﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BotApp.DataModel
{
    public class Timeline
    {
        [JsonProperty(PropertyName = "Id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "CurrentCurrency")]
        public string CurrentCurrency { get; set; }

        [JsonProperty(PropertyName = "createdAt")]
        public DateTime Date { get; set; }


    }
}