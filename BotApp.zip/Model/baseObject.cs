﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BotApp.Model
{
    public class baseObject
    {
        public class Currencies
        {
            public string currencyCode { get; set; }
            public string currencyDescription { get; set; }
        }
        public class CurrencieObject
        {
            public List<Currencies> currencies { get; set; }

        }
    }

}