﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using BotApp.Model2;
using System.Collections.Generic;
using BotApp.DataModel;




namespace BotApp
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// </summary>
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {
            if (activity.Type == ActivityTypes.Message)
            {
                ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));

                StateClient stateClient = activity.GetStateClient();
                BotData userData = await stateClient.BotState.GetUserDataAsync(activity.ChannelId, activity.From.Id);

                var userMessage = activity.Text;

                string endOutput = "";

                // calculate something for us to return
                if (userData.GetProperty<bool>("SentGreeting"))
                {
                    endOutput = "Hello \n";
                }
                else
                {
                    userData.SetProperty<bool>("SentGreeting", true);
                    await stateClient.BotState.SetUserDataAsync(activity.ChannelId, activity.From.Id, userData);
                }

                bool isRateRequest = true;

                if (userMessage.ToLower().Contains("clear"))
                {
                    endOutput = "User data cleared";
                    await stateClient.BotState.DeleteStateForUserAsync(activity.ChannelId, activity.From.Id);
                    isRateRequest = false;
                }

                if (userMessage.Length > 21)
                {
                    if (userMessage.ToLower().Substring(0, 20).Equals("set current currency"))
                    {
                        string homeCity = userMessage.Substring(21);
                        userData.SetProperty<string>("HomeCity", homeCity);
                        await stateClient.BotState.SetUserDataAsync(activity.ChannelId, activity.From.Id, userData);
                        endOutput = "Current Currency is now "+homeCity;
                        isRateRequest = false;
                    }
                }

                if (userMessage.ToLower().Equals("rate"))
                {
                    string homecity = userData.GetProperty<string>("HomeCity");
                    if (homecity == null)
                    {
                        endOutput = "Home City not assigned";
                        isRateRequest = false;
                    }
                    else
                    {
                        activity.Text = homecity;

                    }
                }
                if (userMessage.ToLower().Equals("good morning"))
                {
                    endOutput = "Good Morning! How can i help you?";

                }
                if (userMessage.ToLower().Equals("hello"))
                {
                    endOutput = "Hello! How can i help you?";

                }
                if (userMessage.ToLower().Equals("thank you"))
                {
                    endOutput = " Have a nice day! :)";

                }

                if (userMessage.ToLower().Equals("get timelines"))
                {
                    List<Timeline> timelines = await AzureManager.AzureManagerInstance.GetTimelines();
                    foreach (Timeline t in timelines)
                    {
                        if((t.CurrentCurrency.ToUpper() == "NZD")|| (t.CurrentCurrency.ToUpper() == "USD"))
                        {
                            endOutput += "You have used " + t.CurrentCurrency + " at " + t.Date + "\n\n";
                        }
                        else if ((t.CurrentCurrency.ToUpper() == "CHF") || (t.CurrentCurrency.ToUpper() == "AUD"))
                        {
                            endOutput += "You have used " + t.CurrentCurrency + " at " + t.Date + "\n\n";
                        }
                        else if ((t.CurrentCurrency.ToUpper() == "GBP") || (t.CurrentCurrency.ToUpper() == "EUR"))
                        {
                            endOutput += "You have used " + t.CurrentCurrency + " at " + t.Date + "\n\n";
                        }
                        else if ((t.CurrentCurrency.ToUpper() == "KRW") || (t.CurrentCurrency.ToUpper() == "PLN"))
                        {
                            endOutput += "You have used " + t.CurrentCurrency + " at " + t.Date + "\n\n";
                        }
                    }
                    isRateRequest = false;

                }

                if (userMessage.ToLower().Equals("add current currency"))
                {
                    string homecity = userData.GetProperty<string>("HomeCity");
                    Timeline timeline = new Timeline()
                    {
                        CurrentCurrency = homecity,
                        Date = DateTime.Now
                    };

                    await AzureManager.AzureManagerInstance.AddTimeline(timeline);

                    isRateRequest = false;

                    endOutput = "New timeline added [" + timeline.Date + "]";
                }

                if (userMessage.ToLower().Equals("resource"))
                {
                    Activity replyToConversation = activity.CreateReply("base Country");
                    replyToConversation.Recipient = activity.From;
                    replyToConversation.Type = "message";
                    replyToConversation.Attachments = new List<Attachment>();
                    List<CardImage> cardImages = new List<CardImage>();
                    cardImages.Add(new CardImage(url: "https://currencylayer.com/images/icons/currencylayer_icon.png"));
                    List<CardAction> cardButtons = new List<CardAction>();
                    CardAction plButton = new CardAction()
                    {
                        Value = "https://currencylayer.com/",
                        Type = "openUrl",
                        Title = "Currencylayer"
                    };
                    cardButtons.Add(plButton);
                    ThumbnailCard plCard = new ThumbnailCard()
                    {
                        Title = "Visit Our Resource center",
                        Subtitle = "Resource provider Currencylayer is here!",
                        Images = cardImages,
                        Buttons = cardButtons
                    };
                    Attachment plAttachment = plCard.ToAttachment();
                    replyToConversation.Attachments.Add(plAttachment);
                    await connector.Conversations.SendToConversationAsync(replyToConversation);

                    return Request.CreateResponse(HttpStatusCode.OK);

                }


                if (!isRateRequest)
                {
                    // return our reply to the user
                    Activity infoReply = activity.CreateReply(endOutput);

                    await connector.Conversations.ReplyToActivityAsync(infoReply);

                }
                else
                {

                    ratebaseObject.RootObject rootObject;

                    HttpClient client = new HttpClient();
                    string currencyrate = await client.GetStringAsync(new Uri("http://apilayer.net/api/live?access_key=5ed9a22cc5f9a3814f5c9c59bba42921&currencies=AUD,CHF,EUR,GBP,PLN,NZD,KRW,USD"));

                    rootObject = JsonConvert.DeserializeObject<ratebaseObject.RootObject>(currencyrate);

                    if (activity.Text.ToUpper() == "KRW")
                    {
                        double currate = rootObject.quotes.USDKRW;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/commons/0/09/Flag_of_South_Korea.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "USD")
                    {
                        double currate = rootObject.quotes.USDUSD;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/en/a/a4/Flag_of_the_United_States.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "NZD")
                    {
                        double currate = rootObject.quotes.USDNZD;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/commons/3/3e/Flag_of_New_Zealand.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "PLN")
                    {
                        double currate = rootObject.quotes.USDPLN;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/commons/0/0b/PLN-flag.PNG"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "GBP")
                    {
                        double currate = rootObject.quotes.USDGBP;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/commons/3/3e/Flag_of_New_Zealand.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "EUR")
                    {
                        double currate = rootObject.quotes.USDEUR;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/commons/b/b7/Flag_of_Europe.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "CHF")
                    {
                        double currate = rootObject.quotes.USDCHF;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/commons/0/08/Flag_of_Switzerland_%28Pantone%29.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);

                    }
                    else if (activity.Text.ToUpper() == "AUD")
                    {
                        double currate = rootObject.quotes.USDAUD;
                        // return our reply to the user
                        Activity reply = activity.CreateReply($"Currency exchange rate for {activity.Text}");
                        reply.Recipient = activity.From;
                        reply.Type = "message";
                        reply.Attachments = new List<Attachment>();

                        List<CardImage> cardImages = new List<CardImage>();
                        cardImages.Add(new CardImage(url: "https://upload.wikimedia.org/wikipedia/en/b/b9/Flag_of_Australia.svg"));

                        List<CardAction> cardButtons = new List<CardAction>();
                        CardAction plButton = new CardAction()
                        {
                            Value = "https://currencylayer.com/",
                            Type = "openUrl",
                            Title = "More Info"
                        };
                        cardButtons.Add(plButton);

                        ThumbnailCard plCard = new ThumbnailCard()
                        {
                            Title = "Exchange Rate From USD To " + activity.Text,
                            Subtitle = currate.ToString(),
                            Images = cardImages,
                            Buttons = cardButtons
                        };

                        Attachment plAttachment = plCard.ToAttachment();
                        reply.Attachments.Add(plAttachment);
                        await connector.Conversations.SendToConversationAsync(reply);
                    }

                }
            }
            else
            {
                HandleSystemMessage(activity);
            }
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }



        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.DeleteUserData)
            {
                // Implement user deletion here
                // If we handle user deletion, return a real message
            }
            else if (message.Type == ActivityTypes.ConversationUpdate)
            {
                // Handle conversation state changes, like members being added and removed
                // Use Activity.MembersAdded and Activity.MembersRemoved and Activity.Action for info
                // Not available in all channels
            }
            else if (message.Type == ActivityTypes.ContactRelationUpdate)
            {
                // Handle add/remove from contact lists
                // Activity.From + Activity.Action represent what happened
            }
            else if (message.Type == ActivityTypes.Typing)
            {
                // Handle knowing tha the user is typing
            }
            else if (message.Type == ActivityTypes.Ping)
            {
            }

            return null;
        }
    }
}