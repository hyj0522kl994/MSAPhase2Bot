﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BotApp.Model2
{
    public class ratebaseObject
    {
        public class Quotes

        {
            public double USDAUD { get; set; }
            public double USDCHF { get; set; }
            public double USDEUR { get; set; }
            public double USDGBP { get; set; }
            public double USDPLN { get; set; }
            public double USDKRW { get; set; }
            public double USDUSD { get; set; }
            public double USDNZD { get; set; }

        }
        public class RootObject
        {
            public Quotes quotes { get; set; }
            public string source { get; set; }
        }
    }
}